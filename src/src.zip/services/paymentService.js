import axios from "axios"
import { encryptPayload } from "../lib/crypto"
import "dotenv/config"

/**
 * Creates a checkout session with DL PAY
 * @param {Object} orderData - Order data from your application
 * @returns {Promise<Object>} - DL PAY checkout response
 */
export async function createCheckout(orderData) {
  try {
    // Get the secret key and API key from environment variables
    const secretKey = process.env.DL_PAY_SECRET_KEY
    const apiKey = process.env.DL_PAY_API_KEY

    if (!secretKey) {
      throw new Error("DL_PAY_SECRET_KEY is not defined in environment variables")
    }

    if (!apiKey) {
      throw new Error("DL_PAY_API_KEY is not defined in environment variables")
    }

    // Format the payload according to DL PAY requirements
    const payload = {
      products: [
        {
          name: orderData.packageName || "Game Package",
          image: orderData.image || undefined,
          price: orderData.price,
          productId: orderData.packageId || `pkg-${Date.now()}`,
          quantity: 1,
        },
      ],
      currency: orderData.currency || "USD",
    }

    // Encrypt the payload
    const encryptedPayload = encryptPayload(payload, secretKey)

    // Send the request to DL PAY with API key in headers
    const response = await axios.post(
      "https://pay.api.dreamslab.dev/api/checkout",
      { payload: encryptedPayload },
      {
        headers: {
          "Content-Type": "application/json",
          "X-API-Key": apiKey,
        },
      },
    )

    // Return the checkout data
    return {
      success: true,
      id: response.data.data.transactionId,
      redirectUrl: response.data.data.redirectUrl,
      amount: response.data.data.amount,
      currency: response.data.data.currency,
      createdAt: response.data.data.createdAt,
    }
  } catch (error) {
    console.error("DL PAY checkout error:", error)

    // Provide detailed error information
    throw new Error(error.response?.data?.message || error.message || "Failed to create DL PAY checkout")
  }
}

/**
 * Verifies a payment with DL PAY
 * @param {string} sessionId - The session ID of the payment
 * @returns {Promise<Object>} - DL PAY payment details
 */
export async function verifyPayment(sessionId) {
  try {
    const apiKey = process.env.DL_PAY_API_KEY

    if (!apiKey) {
      throw new Error("DL_PAY_API_KEY is not defined in environment variables")
    }

    const response = await axios.get(`https://pay.api.dreamslab.dev/api/transaction/${sessionId}`, {
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": apiKey,
      },
    })

    return response.data
  } catch (error) {
    console.error("Error verifying payment:", error)
    throw error
  }
}

export default {
  createCheckout,
  verifyPayment,
}
