import { NextResponse } from "next/server"
import { encryptPayload, decryptPayload } from "@/lib/crypto"
import axios from "axios"

export async function GET(request) {
  try {
    // Check if the secret key is available
    const secretKey = process.env.DL_PAY_SECRET_KEY
    if (!secretKey) {
      return NextResponse.json(
        {
          success: false,
          error: "DL_PAY_SECRET_KEY is not defined in environment variables",
        },
        { status: 500 },
      )
    }

    // Test encryption and decryption
    const testPayload = {
      products: [
        {
          name: "Test Product",
          price: 0.99,
          productId: "test-" + Date.now(),
          quantity: 1,
        },
      ],
      currency: "USD",
    }

    // Test encryption
    console.log("Testing encryption with payload:", JSON.stringify(testPayload, null, 2))
    const encrypted = encryptPayload(testPayload, secretKey)
    console.log("Encrypted payload:", encrypted)

    // Test decryption
    const decrypted = decryptPayload(encrypted, secretKey)
    console.log("Decrypted payload:", JSON.stringify(decrypted, null, 2))

    // Test API connection
    try {
      console.log("Testing API connection to DL PAY...")
      const response = await axios.post(
        "https://pay.api.dreamslab.dev/api/checkout",
        { payload: encrypted },
        {
          headers: {
            "Content-Type": "application/json",
          },
        },
      )

      console.log("API response:", JSON.stringify(response.data, null, 2))

      return NextResponse.json({
        success: true,
        message: "DL PAY integration test successful",
        encryptionTest: {
          original: testPayload,
          encrypted: encrypted.substring(0, 50) + "...", // Truncate for readability
          decrypted: decrypted,
        },
        apiTest: {
          status: response.status,
          data: response.data,
        },
      })
    } catch (apiError) {
      console.error("API test failed:", apiError)

      const errorDetails = {
        message: apiError.message,
      }

      if (apiError.response) {
        errorDetails.status = apiError.response.status
        errorDetails.data = apiError.response.data
      }

      return NextResponse.json(
        {
          success: false,
          message: "Encryption/decryption successful but API test failed",
          encryptionTest: {
            success: true,
            original: testPayload,
            encrypted: encrypted.substring(0, 50) + "...", // Truncate for readability
            decrypted: decrypted,
          },
          apiTest: {
            success: false,
            error: errorDetails,
          },
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Test failed:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 },
    )
  }
}
