import { NextResponse } from "next/server"

export async function GET() {
  try {
    const secretKey = process.env.DL_PAY_SECRET_KEY

    // Check if the key exists
    if (!secretKey) {
      return NextResponse.json({
        error: "DL_PAY_SECRET_KEY is not defined in environment variables",
        exists: false,
      })
    }

    // Check key length
    const keyLength = secretKey.length
    const isValidLength = keyLength === 64

    // Check if key contains only hex characters
    const isValidHex = /^[0-9a-f]+$/i.test(secretKey)

    // Create a masked version of the key for display
    const maskedKey =
      secretKey.length > 8
        ? `${secretKey.substring(0, 4)}...${secretKey.substring(secretKey.length - 4)}`
        : "Key too short"

    return NextResponse.json({
      exists: true,
      length: keyLength,
      isValidLength,
      isValidHex,
      maskedKey,
      isValid: isValidLength && isValidHex,
      message: isValidLength && isValidHex ? "Secret key appears to be valid" : "Secret key is invalid",
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Error checking secret key",
        message: error.message,
      },
      { status: 500 },
    )
  }
}
