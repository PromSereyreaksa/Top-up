import { NextResponse } from "next/server"
import dbConnect from "@/lib/dbConnect"
import Order from "@/db/Order"
import { verifyPayment } from "@/services/paymentService"
import { io } from "@/lib/socket"
import { decryptPayload } from "@/lib/crypto"
import { emitOrderUpdate } from "@/lib/socket"

// This is a webhook handler that will be called by the payment service
export async function POST(request) {
  try {
    await dbConnect()
    const body = await request.json()

    // Verify the webhook payload
    if (!body.payload) {
      // Existing webhook logic
      const signature = request.headers.get("x-signature")

      // Verify webhook signature (implementation depends on the payment service)
      // This is a placeholder for verification logic
      // const isValid = verifySignature(body, signature, process.env.WEBHOOK_SECRET);
      // if (!isValid) {
      //   return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
      // }

      try {
        // Extract payment information from the webhook
        const { id: paymentId, status, metadata } = body

        // Find the corresponding order
        const order = await Order.findOne({ paymentId })
        if (!order) {
          return NextResponse.json({ error: "Order not found" }, { status: 404 })
        }

        // If payment is successful, update order status
        if (status === "completed") {
          // Double-check payment status with the API for additional security
          const paymentDetails = await verifyPayment(paymentId)

          if (paymentDetails.status === "completed") {
            order.status = "completed"
            await order.save()

            // Emit socket event to notify clients (if applicable)
            if (io) {
              io.emit("payment:completed", {
                orderId: order._id,
                gameId: order.game,
                userId: order.userId,
                serverId: order.serverId,
              })
            }

            // Here you would implement game-specific logic like:
            // - Adding credits to the user's account
            // - Triggering game-specific API calls
            // - Sending confirmation emails, etc.
          }
        } else if (status === "failed") {
          order.status = "failed"
          await order.save()

          // Notify via socket if needed
          if (io) {
            io.emit("payment:failed", { orderId: order._id })
          }
        }

        return NextResponse.json({ success: true })
      } catch (error) {
        console.error("Webhook error:", error)
        return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
      }
    }

    // Decrypt the payload
    const SECRET_KEY = process.env.DL_PAY_SECRET_KEY
    const decryptedPayload = decryptPayload(body.payload, SECRET_KEY)

    // Extract transaction details
    const { transactionId, status, amount, currency } = decryptedPayload

    // Find the order by transaction ID
    const order = await Order.findOne({ transactionId })
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    // Update order status based on payment status
    if (status === "COMPLETED") {
      order.paymentStatus = "paid"
      order.fulfillmentStatus = "pending" // Ready for fulfillment
    } else if (status === "FAILED") {
      order.paymentStatus = "failed"
    }

    order.updatedAt = new Date()
    await order.save()

    // Emit socket event for real-time updates
    emitOrderUpdate(order)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Failed to process webhook" }, { status: 500 })
  }
}
