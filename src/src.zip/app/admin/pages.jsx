import Games from './games';

export default function AdminPage() {
    return <Games />;
}