// pages/admin/games.js
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function AdminGames() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    fetchGames();
  }, []);

  const fetchGames = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/games');
      if (!res.ok) throw new Error('Failed to fetch games');
      const data = await res.json();
      setGames(data);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteGame = async (gameId) => {
    if (!confirm('Are you sure you want to delete this game?')) return;
    
    try {
      const res = await fetch(`/api/games/${gameId}`, {
        method: 'DELETE',
      });
      
      if (!res.ok) throw new Error('Failed to delete game');
      
      // Refresh games list
      fetchGames();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div className="p-8 text-center">Loading games...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Error: {error}</div>;
  
  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Game Management</h1>
        <Link href="/admin/games/new" className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded">
          Add New Game
        </Link>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-4 border-b text-left">Image</th>
              <th className="py-2 px-4 border-b text-left">ID</th>
              <th className="py-2 px-4 border-b text-left">Name</th>
              <th className="py-2 px-4 border-b text-left">Description</th>
              <th className="py-2 px-4 border-b text-left">Featured</th>
              <th className="py-2 px-4 border-b text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {games.map((game) => (
              <tr key={game.id} className="hover:bg-gray-50">
                <td className="py-2 px-4 border-b">
                  <img 
                    src={game.image} 
                    alt={game.name} 
                    className="w-16 h-16 object-cover"
                  />
                </td>
                <td className="py-2 px-4 border-b">{game.id}</td>
                <td className="py-2 px-4 border-b">{game.name}</td>
                <td className="py-2 px-4 border-b">{game.description || '-'}</td>
                <td className="py-2 px-4 border-b">
                  {game.featured ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Yes
                    </span>
                  ) : (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                      No
                    </span>
                  )}
                </td>
                <td className="py-2 px-4 border-b">
                  <div className="flex space-x-2">
                    <Link href={`/admin/games/edit/${game.id}`} className="text-blue-500 hover:text-blue-700">
                      Edit
                    </Link>
                    <button 
                      onClick={() => deleteGame(game.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// pages/admin/games/edit/[id].js
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function EditGame() {
  const router = useRouter();
  const { id } = router.query;
  
  const [formData, setFormData] = useState({
    name: '',
    image: '',
    discount: '',
    description: '',
    featured: false
  });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState(null);
  
  useEffect(() => {
    if (id) {
      fetchGame();
    }
  }, [id]);
  
  const fetchGame = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/games/${id}`);
      if (!res.ok) throw new Error('Failed to fetch game');
      
      const game = await res.json();
      setFormData({
        name: game.name || '',
        image: game.image || '',
        discount: game.discount || '',
        description: game.description || '',
        featured: game.featured || false
      });
      
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    
    try {
      const res = await fetch(`/api/games/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      if (!res.ok) throw new Error('Failed to update game');
      
      setMessage('Game updated successfully!');
      setTimeout(() => router.push('/admin/games'), 1500);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  if (loading && !formData.name) return <div className="p-8 text-center">Loading game data...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Error: {error}</div>;
  
  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Edit Game: {formData.name}</h1>
      
      {message && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {message}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
          />
        </div>
        
        <div>
          <label className="block mb-1">Image URL</label>
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
          />
        </div>
        
        <div>
          <label className="block mb-1">Discount (optional)</label>
          <input
            type="text"
            name="discount"
            value={formData.discount}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
          />
        </div>
        
        <div>
          <label className="block mb-1">Description (optional)</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2 h-24"
          />
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="featured"
            name="featured"
            checked={formData.featured}
            onChange={handleChange}
            className="mr-2"
          />
          <label htmlFor="featured">Featured Game</label>
        </div>
        
        <div className="flex gap-4">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
          
          <Link href="/admin/games" className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded">
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}

// pages/admin/games/new.js
import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function NewGame() {
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    image: '',
    discount: '',
    description: '',
    featured: false
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch('/api/games', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to create game');
      }
      
      router.push('/admin/games');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Add New Game</h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Game ID (unique identifier)</label>
          <input
            type="text"
            name="id"
            value={formData.id}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
            placeholder="e.g., mobile-legends"
          />
          <p className="text-xs text-gray-500 mt-1">
            Use lowercase letters, numbers, and hyphens only. This will be used in URLs.
          </p>
        </div>
        
        <div>
          <label className="block mb-1">Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
            placeholder="e.g., Mobile Legends"
          />
        </div>
        
        <div>
          <label className="block mb-1">Image URL</label>
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            required
            placeholder="/images/game-name.jpg"
          />
        </div>
        
        <div>
          <label className="block mb-1">Discount (optional)</label>
          <input
            type="text"
            name="discount"
            value={formData.discount}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2"
            placeholder="e.g., 10% OFF"
          />
        </div>
        
        <div>
          <label className="block mb-1">Description (optional)</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            className="w-full border rounded px-3 py-2 h-24"
            placeholder="Brief description of the game or special offers"
          />
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="featured"
            name="featured"
            checked={formData.featured}
            onChange={handleChange}
            className="mr-2"
          />
          <label htmlFor="featured">Featured Game</label>
        </div>
        
        <div className="flex gap-4">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
            disabled={loading}
          >
            {loading ? 'Creating...' : 'Create Game'}
          </button>
          
          <Link href="/admin/games" className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded">
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}